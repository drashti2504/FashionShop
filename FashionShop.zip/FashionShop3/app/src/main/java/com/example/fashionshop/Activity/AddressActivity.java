package com.example.fashionshop.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fashionshop.Helper.ReadWriteuserDetails;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivityAddressBinding;
import com.example.fashionshop.databinding.ActivityCartBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AddressActivity extends BaseActivity {

    ActivityAddressBinding binding;
    EditText houseNo,area,pincode,city,state,option,pname,contactNo;
    private FirebaseAuth authProfile;
    FirebaseUser firebaseUser;
    String price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityAddressBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().setFlags(1024,1024);

        price = getIntent().getStringExtra("price");

        houseNo = findViewById(R.id.houseNo);
        area = findViewById(R.id.area);
        pincode = findViewById(R.id.pincode);
        city = findViewById(R.id.city);
        state = findViewById(R.id.state);
        option = findViewById(R.id.option);
        pname = findViewById(R.id.pname);
        contactNo = findViewById(R.id.contactNo);

        authProfile = FirebaseAuth.getInstance();
        firebaseUser = authProfile.getCurrentUser();


        if(firebaseUser == null){
            AlertDialog.Builder builder = new AlertDialog.Builder(AddressActivity.this);
            builder.setTitle("Login Required");
            builder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(AddressActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            //Create the AlertDialog
            AlertDialog alertDialog = builder.create();

            //Show the AlertDialog
            alertDialog.show();
        } else {
            binding.saveBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String strhouseNo = houseNo.getText().toString();
                    String strarea = area.getText().toString();
                    String strpincode = pincode.getText().toString();
                    String strcity = city.getText().toString();
                    String strstate = state.getText().toString();
                    String stroption = option.getText().toString();
                    String strpname = pname.getText().toString();
                    String strcontactNo = contactNo.getText().toString();

//                    String address = "";
//
//                    if(!strhouseNo.isEmpty()){
//                        address+=strhouseNo;
//                    }
//                    if(!strarea.isEmpty()){
//                        address+=strarea;
//                    }
//                    if(!strcity.isEmpty()){
//                        address+=strcity;
//                    }
//                    if(!strstate.isEmpty()){
//                        address+=strstate;
//                    }
//                    if(!strpincode.isEmpty()){
//                        address+=strpincode;
//                    }

                    if(TextUtils.isEmpty(strhouseNo)){
                        Toast.makeText(AddressActivity.this,"Please enter your houseNo",Toast.LENGTH_LONG).show();
                        houseNo.setError("houseNo is required");
                        houseNo.requestFocus();
                    } else if(TextUtils.isEmpty(strarea)){
                        Toast.makeText(AddressActivity.this,"Please enter your area",Toast.LENGTH_LONG).show();
                        area.setError("area is required");
                        area.requestFocus();
                    } else if(TextUtils.isEmpty(strpincode)){
                        Toast.makeText(AddressActivity.this,"Please enter your pincode",Toast.LENGTH_LONG).show();
                        pincode.setError("pincode is required");
                        pincode.requestFocus();
                    } else if(TextUtils.isEmpty(strcity)){
                        Toast.makeText(AddressActivity.this,"Please enter your city",Toast.LENGTH_LONG).show();
                        city.setError("city is required");
                        city.requestFocus();
                    } else if (TextUtils.isEmpty(strstate)) {
                        Toast.makeText(AddressActivity.this,"Please enter your state",Toast.LENGTH_LONG).show();
                        state.setError("state is required");
                        state.requestFocus();
                    } else if (TextUtils.isEmpty(strpname)) {
                        Toast.makeText(AddressActivity.this,"Please enter your name",Toast.LENGTH_LONG).show();
                        pname.setError("pincode is required");
                        pname.requestFocus();
                    } else if (TextUtils.isEmpty(strcontactNo)) {
                        Toast.makeText(AddressActivity.this,"Please enter your contactNo",Toast.LENGTH_LONG).show();
                        contactNo.setError("contactNo is required");
                        contactNo.requestFocus();
                    } else {
                        AddressUser(strhouseNo,strarea,strpincode,strcity,strstate,stroption,strpname,strcontactNo);
                       //  addressUser(address);
                    }
                }
            });

        }

        binding.backBtn.setOnClickListener(v -> {
            Intent intent = new Intent(AddressActivity.this,SelecteAddressActivity.class);
            intent.putExtra("price",price);
            startActivity(intent);
            finish();
        });
    }

    private void AddressUser(String strhouseNo, String strarea, String strpincode, String strcity, String strstate, String stroption, String strpname, String strcontactNo) {
        String userId = firebaseUser.getUid();

        ReadWriteuserAddress writeuserDetails = new ReadWriteuserAddress(strhouseNo,strarea,strpincode,strcity,strstate,stroption,strpname,strcontactNo);

        DatabaseReference referenceAddress = FirebaseDatabase.getInstance().getReference("Address User");

        String addressId = referenceAddress.push().getKey();

        referenceAddress.child(userId).child("addresses").child(addressId).setValue(writeuserDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(AddressActivity.this,"Add Address",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddressActivity.this,SelecteAddressActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("price",price);
                    startActivity(intent);
                    finish();

                }else{
                    String error = task.getException() != null ? task.getException().getMessage() : "Something Went Wrong!";
                    Toast.makeText(AddressActivity.this,error,Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}