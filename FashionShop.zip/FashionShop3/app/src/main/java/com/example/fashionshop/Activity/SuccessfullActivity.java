package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.fashionshop.Domain.ItemsDomain;
import com.example.fashionshop.Helper.ManagmentCart;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivitySuccessfullBinding;

import java.util.List;

public class SuccessfullActivity extends BaseActivity {

    ActivitySuccessfullBinding binding;
    ImageView okanim;
    private ManagmentCart managmentCart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivitySuccessfullBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().setFlags(1024,1024);

        okanim = findViewById(R.id.ok);
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.blink_anim);
        okanim.startAnimation(fadeIn);

        String totalprice = getIntent().getStringExtra("price");
        binding.totalpriceTxt.setText("₹"+totalprice);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SuccessfullActivity.this,MyorderActivity.class);
                startActivity(intent);
                finish();
            }
        },3000);

        managmentCart=new ManagmentCart(this);
        completeOrder();
    }

    private void completeOrder() {
        // Clear the cart
        managmentCart.clearCart();
    }

}