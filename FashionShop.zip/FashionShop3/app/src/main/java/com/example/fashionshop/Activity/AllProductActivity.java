package com.example.fashionshop.Activity;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.fashionshop.Adapter.CategoryAdapter;
import com.example.fashionshop.Adapter.PopularAdapter;
import com.example.fashionshop.Domain.CategoryDomain;
import com.example.fashionshop.Domain.ItemsDomain;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivityAllProductBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AllProductActivity extends BaseActivity {

    private ActivityAllProductBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAllProductBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().setFlags(1024,1024);


        setVeriable();
        initPopularseelAll();
        displayHeader();
//        searchProduct();

    }

    @Override
    protected void onResume() {
        super.onResume();
        searchProduct();
    }
    private void displayHeader() {
        String type = getIntent().getStringExtra("type");
        String category = getIntent().getStringExtra("Category");
        String query = getIntent().getStringExtra("query");

        if ("Category".equalsIgnoreCase(type) && category != null && !category.isEmpty()) {
            binding.categoryheader.setText(category);
        } else if ("search".equalsIgnoreCase(type) && query != null && !query.isEmpty()) {
            binding.categoryheader.setText(query);
        } else {
            binding.categoryheader.setText("You & me");
        }
    }

//    private void setVeriable() {
//        binding.backBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(AllProductActivity.this,MainActivity.class);
//                startActivity(intent);
//                finish();
//            }
//        });
//    }
private void setVeriable() {
    binding.backBtn.setOnClickListener(v -> finish());  // Simply finish the activity
}


    private void searchProduct() {
        String type = getIntent().getStringExtra("type");

        if (type != null) {
            if (type.equalsIgnoreCase("Category")) {
                filterByCategory();
            } else if (type.equalsIgnoreCase("search")) {
                loadByPopular();
            } else {
                initPopularseelAll();
            }
        }
    }


    private void filterByCategory() {
        DatabaseReference myRef=database.getReference("Items");

        String category = getIntent().getStringExtra("Category");

        myRef.orderByChild("Category").equalTo(category).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<ItemsDomain> itemsList = new ArrayList<>();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    ItemsDomain itemsDomainList = dataSnapshot.getValue(ItemsDomain.class);
                        itemsList.add(itemsDomainList);
                }
                PopularAdapter adapter = (PopularAdapter) binding.recyclerviewPopular.getAdapter();
                if(adapter != null){
                   adapter.setProductList(itemsList);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Error",error.getMessage());
            }
        });
    }

    private void loadByPopular() {
        DatabaseReference myRef=database.getReference("Items");

        String query = getIntent().getStringExtra("query");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<ItemsDomain> itemsList = new ArrayList<>();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    ItemsDomain itemsDomainList = dataSnapshot.getValue(ItemsDomain.class);
                    if (itemsDomainList.getTitle().toLowerCase().contains(query.toLowerCase())){
                        itemsList.add(itemsDomainList);
                    }
                }
                PopularAdapter adapter = (PopularAdapter) binding.recyclerviewPopular.getAdapter();
                if(adapter != null){
                    adapter.setProductList(itemsList);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Error",error.getMessage());
            }
        });

    }

    private void  initPopularseelAll() {
        DatabaseReference myRef=database.getReference("Items");
        binding.progressBarPopular.setVisibility(View.VISIBLE);
        ArrayList<ItemsDomain> items=new ArrayList<>();

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    for (DataSnapshot issue:snapshot.getChildren()) {
                        items.add(issue.getValue(ItemsDomain.class));
                    }
                    if(!items.isEmpty()){
                        binding.recyclerviewPopular.setLayoutManager(new GridLayoutManager(AllProductActivity.this,2));
                        binding.recyclerviewPopular.setAdapter(new PopularAdapter(items));

                    }
                    binding.progressBarPopular.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Error",error.getMessage());
            }
        });

    }
}