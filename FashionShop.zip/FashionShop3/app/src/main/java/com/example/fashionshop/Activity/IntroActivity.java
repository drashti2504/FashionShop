package com.example.fashionshop.Activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fashionshop.R;

public class IntroActivity extends AppCompatActivity {

    TextView txtc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_intro);

        txtc = findViewById(R.id.txtcolor);
        findViewById(R.id.getstart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(IntroActivity.this, MainActivity.class));
            }
        });

        String text1 = "The Fashion App That \n Makes You Look Your Best";
        SpannableString spannableString = new SpannableString(text1);
        ForegroundColorSpan coffee = new ForegroundColorSpan(Color.parseColor("#704F38"));
        spannableString.setSpan(coffee,4,15, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        txtc.setText(spannableString);

    }

    public void signin(View view){
        startActivity(new Intent(IntroActivity.this, RegistrationActivity.class));
    }
}