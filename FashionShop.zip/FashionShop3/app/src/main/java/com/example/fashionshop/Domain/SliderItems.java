package com.example.fashionshop.Domain;

public class SliderItems {
    private String url;

    public SliderItems() {
    }

    public SliderItems(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
