package com.example.fashionshop.Helper;

public interface ChangeNumberItemsListener {
    void changed();
}
