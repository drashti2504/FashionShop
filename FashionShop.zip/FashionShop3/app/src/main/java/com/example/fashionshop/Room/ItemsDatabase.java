package com.example.fashionshop.Room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


import com.example.fashionshop.Domain.WishlistDomain;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


//insert and delete favourite code from database all data

@Database(entities = {WishlistDomain.class}, version = 1, exportSchema = false)
public abstract class ItemsDatabase extends RoomDatabase {

    public static ItemsDatabase getInstance() {
        return instance;
    }

    public static void setInstance(ItemsDatabase instance) {
        ItemsDatabase.instance = instance;
    }

    public abstract ItemsDao favouriteDao();
    private static ItemsDatabase instance = null;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static synchronized ItemsDatabase getInstance(Context context) {
        if (getInstance() == null) {
            setInstance(Room.databaseBuilder(context.getApplicationContext(), ItemsDatabase.class, "items_database")
                    .fallbackToDestructiveMigration()
                    .build());
        }
        return getInstance();
    }
}
