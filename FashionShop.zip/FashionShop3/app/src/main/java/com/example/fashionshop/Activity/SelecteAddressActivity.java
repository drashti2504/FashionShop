package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.fashionshop.Adapter.AddressAdapter;
import com.example.fashionshop.Domain.AddressDomain;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivitySelecteAddressBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SelecteAddressActivity extends BaseActivity {
    ActivitySelecteAddressBinding binding;
    private FirebaseAuth authProfile;
    FirebaseUser firebaseUser;
    String pname, address, contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelecteAddressBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        String price = getIntent().getStringExtra("price");

        getWindow().setFlags(1024, 1024);

        binding.backBtn.setOnClickListener(v -> {
            Intent intent = new Intent(SelecteAddressActivity.this, CartActivity.class);
            startActivity(intent);
            finish();
        });

        binding.addAddress.setOnClickListener(v -> {
            Intent intent = new Intent(SelecteAddressActivity.this, AddressActivity.class);
            intent.putExtra("price", price);
            startActivity(intent);
            finish();
        });

        binding.continueBtn.setOnClickListener(v -> {
            AddressAdapter adapter = (AddressAdapter) binding.addressrecycler.getAdapter();
            AddressDomain selectedAddress = adapter.getSelectedAddress();

            if (selectedAddress != null) {
                Intent intent = new Intent(SelecteAddressActivity.this, PaymentActivity.class);
                intent.putExtra("price", price);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(SelecteAddressActivity.this, "Please select an address", Toast.LENGTH_SHORT).show();
            }
        });

        authProfile = FirebaseAuth.getInstance();
        firebaseUser = authProfile.getCurrentUser();

        if (firebaseUser != null) {
            showAddressDetail(firebaseUser);
        } else {
            Toast.makeText(SelecteAddressActivity.this, "User not authenticated", Toast.LENGTH_SHORT).show();
            Log.e("SelecteAddressActivity", "FirebaseUser is null");
        }
    }

    private void showAddressDetail(FirebaseUser firebaseUser) {
        String userId = firebaseUser.getUid();
        ArrayList<AddressDomain> addressList = new ArrayList<>();

        DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Address User");
        referenceProfile.child(userId).child("addresses").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                addressList.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        AddressDomain addressItem = issue.getValue(AddressDomain.class);
//                        Log.d("AddressListSize", "Number of addresses: " + addressList.size());
                        if (addressItem != null) {
                            addressList.add(addressItem);
                            Log.d("Address", "Address added: " + addressItem.getName());
                        }
                    }

                    if (!addressList.isEmpty()) {

                        binding.addressrecycler.setLayoutManager(new LinearLayoutManager(SelecteAddressActivity.this));
                        binding.addressrecycler.setAdapter(new AddressAdapter(addressList));
                       // Toast.makeText(SelecteAddressActivity.this, "Addresses loaded successfully.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(SelecteAddressActivity.this, "Something Went Wrong!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(SelecteAddressActivity.this, "Please Add the Delivery Address", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(SelecteAddressActivity.this, "Failed to load addresses", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
