package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fashionshop.Helper.ReadWriteuserDetails;
import com.example.fashionshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UpdateProfileActivity extends AppCompatActivity {

    private EditText edupname, edupmobileno;
    private Button updatebtn,updatepic;
    private String strname,strmobileno;
    private FirebaseAuth authProfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_profile);

        edupname = findViewById(R.id.edittext_update_name);
        edupmobileno = findViewById(R.id.edittext_update_mobile);
        updatebtn = findViewById(R.id.update_profile_btn);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        //show Profile Data
        showProfile(firebaseUser);

        updatepic = findViewById(R.id.update_profile_pic);
        updatepic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UpdateProfileActivity.this, uploadProfileActivity.class);
                startActivity(intent);
            }
        });

        updatebtn = findViewById(R.id.update_profile_btn);
        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateProfile(firebaseUser);
            }
        });


    }

    private void updateProfile(FirebaseUser firebaseUser) {
        if(TextUtils.isEmpty(strname)){
            Toast.makeText(UpdateProfileActivity.this,"Please enter your id",Toast.LENGTH_LONG).show();
            edupname.setError("Name is required");
            edupname.requestFocus();
        }else if(TextUtils.isEmpty(strmobileno)){
            Toast.makeText(UpdateProfileActivity.this, "Please enter mobileno", Toast.LENGTH_SHORT).show();
            edupmobileno.setError("email is required");
            edupmobileno.requestFocus();
        }else{
            strname = edupname.getText().toString();
            strmobileno = edupmobileno.getText().toString();

            ReadWriteuserDetails writeUserDetails = new ReadWriteuserDetails(strname,strmobileno);

            DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Register User");

            String userID = firebaseUser.getUid();

            referenceProfile.child(userID).setValue(writeUserDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder().setDisplayName(strname).build();
                        firebaseUser.updateProfile(profileUpdate);

                        Toast.makeText(UpdateProfileActivity.this, "Update Successful!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(UpdateProfileActivity.this,ProfileActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        try {
                            throw  task.getException();
                        } catch (Exception e){
                            Toast.makeText(UpdateProfileActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }

    }

    private void showProfile(FirebaseUser firebaseUser) {
        String userIDofRegisterUser = firebaseUser.getUid();

        //reference
        DatabaseReference referencerProfile = FirebaseDatabase.getInstance().getReference("Register User");

        referencerProfile.child(userIDofRegisterUser).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ReadWriteuserDetails readWriteuserDetails = snapshot.getValue(ReadWriteuserDetails.class);
                if(readWriteuserDetails != null){
                    strname = firebaseUser.getDisplayName();
                    strmobileno = readWriteuserDetails.mobileno;

                    edupname.setText(strname);
                    edupmobileno.setText(strmobileno);

                } else {
                    Toast.makeText(UpdateProfileActivity.this, "Something Went Wrong!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateProfileActivity.this, "Something Went Wrong!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}