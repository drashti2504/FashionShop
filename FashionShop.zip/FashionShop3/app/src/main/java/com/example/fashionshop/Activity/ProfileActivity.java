package com.example.fashionshop.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.fashionshop.Helper.ManagmentCart;
import com.example.fashionshop.Helper.ReadWriteuserDetails;
import com.example.fashionshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class ProfileActivity extends AppCompatActivity {

    private TextView showwelcome,fullname,email,mobileno;
    private String strfullname,stremail,strmobileno;
    private ImageView profiledp,backbtn,editprofile,deleteaccount;
    private FirebaseAuth authProfile;
    private FirebaseUser firebaseUser;
    Button signout,changepwd;
    private ManagmentCart managmentCart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        showwelcome=findViewById(R.id.show_welcome);
        fullname=findViewById(R.id.show_fullname);
        email=findViewById(R.id.show_email);
        mobileno=findViewById(R.id.show_mobileno);
        profiledp=findViewById(R.id.profile_dp);
        signout = findViewById(R.id.sign_out);
        deleteaccount = findViewById(R.id.delete_account);

        deleteaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlertDialogDeleteAccount();
            }
        });

        SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout)findViewById(R.id.refreshLayout);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                showUserProfile(authProfile.getCurrentUser());
                showwelcome.setText("Welcome "+strfullname+"!");
                fullname.setText(strfullname);
                email.setText(stremail);
                mobileno.setText(strmobileno);
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        profiledp = findViewById(R.id.profile_dp);

        changepwd = findViewById(R.id.change_password);
        changepwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, ChangePasswordActivity.class);
                startActivity(intent);
            }
        });

        editprofile = findViewById(R.id.edit_profile);
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this,UpdateProfileActivity.class);
                startActivity(intent);
            }
        });

        backbtn = findViewById(R.id.backBtn);
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        profiledp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this,uploadProfileActivity.class);
                startActivity(intent);
            }
        });

        managmentCart=new ManagmentCart(this);

        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signoutDialog();
            }
        });

        authProfile = FirebaseAuth.getInstance();
        firebaseUser = authProfile.getCurrentUser();


        if(firebaseUser == null){
            AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
            builder.setTitle("Login Required");
            builder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(ProfileActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            //Create the AlertDialog
            AlertDialog alertDialog = builder.create();

            //Show the AlertDialog
            alertDialog.show();
        } else {
            checkIfEmailVerified(firebaseUser);
            showUserProfile(firebaseUser);
        }
    }

    //delete account
    private void showAlertDialogDeleteAccount() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
        builder.setTitle("Delete Account");
        builder.setMessage("Do you really want to delete your account? This  action is  irreversible.");
        builder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteUser(FirebaseAuth.getInstance().getCurrentUser());
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });

        //Create the AlertDialog
        AlertDialog alertDialog = builder.create();

        //Change the button color of Continue
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.coffee));
            }
        });

        //Show the AlertDialog
        alertDialog.show();

    }

    private void deleteUser(FirebaseUser firebaseUser) {
        if (firebaseUser == null) {
            Toast.makeText(ProfileActivity.this, "No user logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        // Reference to the user's data in the database
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Register User").child(firebaseUser.getUid());

        // Delete the user's data
        userRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    // Once the data is deleted, proceed to delete the user's account
                    firebaseUser.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                FirebaseAuth.getInstance().signOut();
                                Toast.makeText(ProfileActivity.this, "User has been deleted!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                finish();
                            } else {
                                try {
                                    throw task.getException();
                                } catch (Exception e) {
                                    Toast.makeText(ProfileActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });
                } else {
                    Toast.makeText(ProfileActivity.this, "Error deleting user data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    private void signoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
        builder.setMessage("Are you sure sign out?");
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                authProfile.signOut();
                managmentCart.clearCart();
                Toast.makeText(ProfileActivity.this,"logged out",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ProfileActivity.this,LoginActivity.class);
                intent.putExtra("finish",true);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        //Create the AlertDialog
        AlertDialog alertDialog = builder.create();

        //Show the AlertDialog
        alertDialog.show();


    }

    //User coming to MainActivity after successful register
    private void checkIfEmailVerified(FirebaseUser firebaseUser) {
        if(!firebaseUser.isEmailVerified()){
            showAlertDialog();
        }
    }

    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
        builder.setTitle("Email not verified");
        builder.setMessage("Please verify your email now.You can not login without email verification next time.");
        builder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_APP_EMAIL);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        //Create the AlertDialog
        AlertDialog alertDialog = builder.create();

        //Show the AlertDialog
        alertDialog.show();
    }

    private void showUserProfile(FirebaseUser firebaseUser) {
        String userId = firebaseUser.getUid();

        //user reference
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Register User");
        referenceProfile.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ReadWriteuserDetails readUserDetails = snapshot.getValue(ReadWriteuserDetails.class);
                if(readUserDetails != null){
                    strfullname = firebaseUser.getDisplayName();
                    stremail = firebaseUser.getEmail();
                    strmobileno = readUserDetails.mobileno;

                    showwelcome.setText("Welcome "+strfullname+"!");
                    fullname.setText(strfullname);
                    email.setText(stremail);
                    mobileno.setText(strmobileno);
                    //set the dp
                    Uri uri = firebaseUser.getPhotoUrl();
                    Picasso.with(ProfileActivity.this).load(uri).into(profiledp);

                } else{
                    Toast.makeText(ProfileActivity.this, "Something Went Wrong!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity.this,"Something Went Wrong!",Toast.LENGTH_LONG).show();
            }
        });
    }

}