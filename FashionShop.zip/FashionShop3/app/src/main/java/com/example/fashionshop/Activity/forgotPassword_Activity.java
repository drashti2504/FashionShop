package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fashionshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

public class forgotPassword_Activity extends AppCompatActivity {

    private Button forgotpwBtn;
    private EditText registereddemail;
    private FirebaseAuth authProfile;
    private  final static String  TAG = "forgotPassword_Activity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forgot_password);

        forgotpwBtn = findViewById(R.id.forgot_password);
        registereddemail = findViewById(R.id.registered_email);

        forgotpwBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String stremail = registereddemail.getText().toString();

                if(TextUtils.isEmpty(stremail)){
                    Toast.makeText(forgotPassword_Activity.this,"Please enter your registered email",Toast.LENGTH_LONG).show();
                    registereddemail.setError("Email is required");
                    registereddemail.requestFocus();
                } else if(!Patterns.EMAIL_ADDRESS.matcher(stremail).matches()){
                    Toast.makeText(forgotPassword_Activity.this,"Please enter valid email",Toast.LENGTH_LONG).show();
                    registereddemail.setError("valid Email is required");
                    registereddemail.requestFocus();
                } else {
                    resetPassword(stremail);
                }

            }
        });


    }

    private void resetPassword(String email) {
        authProfile = FirebaseAuth.getInstance();

        authProfile.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(forgotPassword_Activity.this,"Password reset link sent to your email",Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(forgotPassword_Activity.this,LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    try{
                        throw task.getException();
                    } catch (FirebaseAuthInvalidUserException e){
                        registereddemail.setError("User does not exists or is no longer valid. Please register again");
                    } catch (Exception e){
                        Log.e(TAG,e.getMessage());
                        Toast.makeText(forgotPassword_Activity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}