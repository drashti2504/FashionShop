package com.example.fashionshop.Room;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;


import com.example.fashionshop.Domain.WishlistDomain;

import java.util.List;


@Dao
public interface ItemsDao {
    @Insert
    long insert(WishlistDomain item);

    @Query("DELETE FROM watch_list WHERE clothid = :id")
    void delete(String id);

    @Query("SELECT * FROM watch_list")
    List<WishlistDomain> getAll();

    @Query("SELECT * FROM watch_list WHERE clothid = :favouriteName")
    WishlistDomain getFavourite(String favouriteName);

    @Query("SELECT * FROM watch_list")
    List<WishlistDomain> getAllFavourites();

}
