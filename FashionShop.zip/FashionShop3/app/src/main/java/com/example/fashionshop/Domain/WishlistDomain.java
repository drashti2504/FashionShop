package com.example.fashionshop.Domain;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "watch_list")
public class WishlistDomain {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String clothid;

    public WishlistDomain(String clothid){
        this.clothid=clothid;
    }
    public long getId(){
        return id;
    }

    public String getClothid(){
        return clothid;
    }

    public void setId(long id) {
        this.id = id;
    }
    public void setClothid(String clothid){
        this.clothid=clothid;
    }
}
