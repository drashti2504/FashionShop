package com.example.fashionshop.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fashionshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    Button signin;
    private EditText loginemail, loginpwd;
    private FirebaseAuth authProfile;
    private static final String TAG ="LoginActivity";
    TextView forgot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        signin = findViewById(R.id.signin);
        forgot = findViewById(R.id.forgot);
        loginemail = findViewById(R.id.email);
        loginpwd = findViewById(R.id.pwd);

        ImageView imageViewshowhidepwd = findViewById(R.id.imageView_show_hide_pwd);
        imageViewshowhidepwd.setImageResource(R.drawable.hide_svgrepo_com);
        imageViewshowhidepwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(loginpwd.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())){
                    //if password is visible
                    loginpwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    imageViewshowhidepwd.setImageResource(R.drawable.hide_svgrepo_com);
                }else{
                    loginpwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    imageViewshowhidepwd.setImageResource(R.drawable.eye_svgrepo_com);
                }

            }
        });

        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,forgotPassword_Activity.class);
                startActivity(intent);
                finish();
            }
        });



        authProfile = FirebaseAuth.getInstance();

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  startActivity(new Intent(LoginActivity.this,MainActivity.class));

                String stremail = loginemail.getText().toString();
                String strpwd = loginpwd.getText().toString();

                if(TextUtils.isEmpty(stremail)){
                    Toast.makeText(LoginActivity.this,"Please enter your email",Toast.LENGTH_LONG).show();
                    loginemail.setError("Email is required");
                    loginemail.requestFocus();
                }else if(!Patterns.EMAIL_ADDRESS.matcher(stremail).matches()){
                    Toast.makeText(LoginActivity.this,"Please re-enter your email",Toast.LENGTH_LONG).show();
                    loginemail.setError("valid email is required");
                    loginemail.requestFocus();
                } else if(TextUtils.isEmpty(strpwd)){
                    Toast.makeText(LoginActivity.this,"Please enter password",Toast.LENGTH_LONG).show();
                    loginpwd.setError("password is required");
                    loginpwd.requestFocus();
                } else {
                    loginUser(stremail,strpwd);
                }
            }

        });
    }

    private void loginUser(String email, String pwd) {
        authProfile.signInWithEmailAndPassword(email,pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    //Get instance of the current User
                    FirebaseUser firebaseUser = authProfile.getCurrentUser();

                    //check if email is verified before user can access their profile
                    if(firebaseUser.isEmailVerified()){
                        Toast.makeText(LoginActivity.this,"You are logged in now",Toast.LENGTH_SHORT).show();
                        //open user profile
                        startActivity(new Intent(LoginActivity.this,MainActivity.class));
                        finish();
                    } else {
                        firebaseUser.sendEmailVerification();
                        authProfile.signOut();
                        showAlertDialog();
                    }

                }else{
                    try{
                        throw task.getException();
                    } catch(FirebaseAuthInvalidUserException e){
                        loginemail.setError("User does not exists or is no longer valid. Please register again");
                        loginemail.requestFocus();
                    } catch (FirebaseAuthInvalidCredentialsException e){
                        loginemail.setError("Invalid credentials. Kindly, check and re-enter");
                        loginemail.requestFocus();
                    } catch (Exception e){
                        Log.e(TAG,e.getMessage());
                        Toast.makeText(LoginActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }



    public void opensignup(View view){
        startActivity(new Intent(LoginActivity.this,RegistrationActivity.class));
    }

    public void appleweb(View view) {
        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(intent.CATEGORY_BROWSABLE);
        intent.setData(android.net.Uri.parse("https://www.apple.com/in/"));
        startActivity(intent);
    }

    public void googleweb(View view) {
        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(intent.CATEGORY_BROWSABLE);
        intent.setData(android.net.Uri.parse("https://www.google.com/"));
        startActivity(intent);
    }

    public void faceweb(View view) {
        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(intent.CATEGORY_BROWSABLE);
        intent.setData(android.net.Uri.parse("https://www.facebook.com/"));
        startActivity(intent);
    }

    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        builder.setTitle("Email not verified");
        builder.setMessage("Please verify your email now.You can not login without verification.");
        builder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_APP_EMAIL);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        //Create the AlertDialog
        AlertDialog alertDialog = builder.create();

        //Show the AlertDialog
        alertDialog.show();
    }

    //Check the User is already logged in.
    @Override
    protected void onStart() {
        super.onStart();
        if(authProfile.getCurrentUser() != null){
            Toast.makeText(LoginActivity.this,"You are already logged in",Toast.LENGTH_LONG).show();

            //start the MainActivity
            startActivity(new Intent(LoginActivity.this,MainActivity.class));
            finish();

        }else {
            Toast.makeText(LoginActivity.this,"You can login now!",Toast.LENGTH_LONG).show();
        }
    }
}