package com.example.fashionshop.Domain;

import java.io.Serializable;

public class AddressDomain implements Serializable {
    private String houseNo;
    private String area;
    private String pincode;
    private String city;
    private String state;
    private String option;
    private String name;
    private String contactNo;


    public AddressDomain() {

    }

    public AddressDomain(String houseNo, String area, String pincode, String city, String state, String option, String name, String contactNo) {
        this.houseNo = houseNo;
        this.area = area;
        this.pincode = pincode;
        this.city = city;
        this.state = state;
        this.option = option;
        this.name = name;
        this.contactNo = contactNo;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getOption() {
        return option;
    }

    public void setOption(String option) {
        this.option = option;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }
}




