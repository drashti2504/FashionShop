package com.example.fashionshop.Domain;

public class CardDetails {

    private String cardNumber;
    private String cardName;
    private String cardExpiry;
    private String cardCVV;

    public CardDetails() {
    }

    public CardDetails(String cardNum, String cardHolderName, String expiry, String cvv) {
        this.cardNumber = cardNum;
        this.cardName = cardHolderName;
        this.cardExpiry = expiry;
        this.cardCVV = cvv;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getCardExpiry() {
        return cardExpiry;
    }

    public void setCardExpiry(String cardExpiry) {
        this.cardExpiry = cardExpiry;
    }

    public String getCardCVV() {
        return cardCVV;
    }

    public void setCardCVV(String cardCVV) {
        this.cardCVV = cardCVV;
    }
}
