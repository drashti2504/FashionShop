package com.example.fashionshop.Activity;

public class ReadWriteuserAddress {
    public String houseNo,area,pincode,city,state,option,name,contactNo;

    public ReadWriteuserAddress() {
    }

    public ReadWriteuserAddress(String houseNo, String area, String pincode, String city, String state, String option, String name, String contactNo){
        this.houseNo = houseNo;
        this.area = area;
        this.pincode = pincode;
        this.city = city;
        this.state = state;
        this.option = option;
        this.name = name;
        this.contactNo = contactNo;
    }
}
