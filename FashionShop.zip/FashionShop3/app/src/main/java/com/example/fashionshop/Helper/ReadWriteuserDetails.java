package com.example.fashionshop.Helper;

public class ReadWriteuserDetails {

    public String name,email,mobileno;

    //Constructor

    public ReadWriteuserDetails(){};

    public ReadWriteuserDetails(String email,String mobileno){
        this.name = name;
        this.email = email;
        this.mobileno = mobileno;
    }

}
