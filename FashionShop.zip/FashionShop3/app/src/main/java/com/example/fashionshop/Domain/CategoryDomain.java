package com.example.fashionshop.Domain;

public class CategoryDomain {
    private String title;
    private int url;
    private String picUrl;

    public CategoryDomain(String title, int url, String picUrl) {
        this.title = title;
        this.url = url;
        this.picUrl = picUrl;
    }

    public CategoryDomain() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getUrl() {
        return url;
    }

    public void setUrl(int url) {
        this.url = url;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }
}
