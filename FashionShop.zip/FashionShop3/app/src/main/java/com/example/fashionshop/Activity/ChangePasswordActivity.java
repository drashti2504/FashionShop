package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.fashionshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePasswordActivity extends AppCompatActivity {

    private EditText currentpwd,newpwd,newcfpwd;
    private Button verifypwdbtn,changepwdbtn;
    private FirebaseAuth authProfile;
    private String userPwdCurrent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_change_password);

        currentpwd = findViewById(R.id.editText_currentpwd);
        newpwd = findViewById(R.id.editText_newpwd);
        newcfpwd = findViewById(R.id.editText_newcfpwd);

        verifypwdbtn = findViewById(R.id.verifypwd_btn);
        changepwdbtn = findViewById(R.id.changepwd_btn);

        //Enable newpassword,confimpassword,changepassword button
        newpwd.setEnabled(false);
        newcfpwd.setEnabled(false);
        changepwdbtn.setEnabled(false);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        if(firebaseUser.equals("")){
            Toast.makeText(ChangePasswordActivity.this,"Something Went Wrong! User's details not available.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(ChangePasswordActivity.this,ProfileActivity.class);
            startActivity(intent);
            finish();
        } else {
            reverifyPassword(firebaseUser);
        }

    }

    private void reverifyPassword(FirebaseUser firebaseUser) {
        verifypwdbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userPwdCurrent = currentpwd.getText().toString();

                if(userPwdCurrent.equals("")){
                    Toast.makeText(ChangePasswordActivity.this,"password is needed",Toast.LENGTH_LONG).show();
                    currentpwd.setError("Please enter your current password");
                    currentpwd.requestFocus();
                } else {
                    AuthCredential credential = EmailAuthProvider.getCredential(firebaseUser.getEmail(),userPwdCurrent);
                    firebaseUser.reauthenticate(credential).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    currentpwd.setEnabled(false);
                                    verifypwdbtn.setEnabled(false);

                                    newpwd.setEnabled(true);
                                    newcfpwd.setEnabled(true);
                                    changepwdbtn.setEnabled(true);

                                    Toast.makeText(ChangePasswordActivity.this, "Password has been verified."+"Change Password now", Toast.LENGTH_SHORT).show();
                                    changepwdbtn.setBackgroundTintList(ContextCompat.getColorStateList(
                                            ChangePasswordActivity.this,
                                            R.color.coffee));

                                    changepwdbtn.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            changepwd(firebaseUser);
                                        }
                                    });
                                } else {
                                    try{
                                        throw task.getException();
                                    } catch (Exception e){
                                        Toast.makeText(ChangePasswordActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                                    }
                                }
                        }
                    });
                }
            }
        });
    }

    private void changepwd(FirebaseUser firebaseUser) {
        String usernewpwd = newpwd.getText().toString();
        String usernewcfpwd = newcfpwd.getText().toString();

        if(TextUtils.isEmpty(usernewpwd)){
            Toast.makeText(ChangePasswordActivity.this,"new password is needed",Toast.LENGTH_LONG).show();
            newpwd.setError("Please enter your new password");
            newpwd.requestFocus();
        } else if(TextUtils.isEmpty(usernewcfpwd)){
            Toast.makeText(ChangePasswordActivity.this,"confirm new password is needed",Toast.LENGTH_LONG).show();
            newcfpwd.setError("Please re-enter your confirm new password");
            newcfpwd.requestFocus();
        } else if(!usernewpwd.matches(usernewcfpwd)){
            Toast.makeText(ChangePasswordActivity.this,"password does not match",Toast.LENGTH_LONG).show();
            newcfpwd.setError("Please re-enter same password");
            newcfpwd.requestFocus();
        } else if (userPwdCurrent.matches(usernewpwd)) {
            Toast.makeText(ChangePasswordActivity.this, "New Password cannot be same as old Password", Toast.LENGTH_SHORT).show();
            newpwd.setError("Please enter a new password");
            newpwd.requestFocus();
        } else {
            firebaseUser.updatePassword(usernewpwd).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(ChangePasswordActivity.this, "Password  has been changed", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ChangePasswordActivity.this,ProfileActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        try{
                            throw task.getException();
                        } catch (Exception e){
                            Toast.makeText(ChangePasswordActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });
        }
    }
}