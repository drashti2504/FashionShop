package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.fashionshop.Adapter.OrderAdapter;
import com.example.fashionshop.Domain.OrderItem;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivityMyorderBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class MyorderActivity extends BaseActivity {

    ActivityMyorderBinding binding;
    private DatabaseReference orderRef;
    private ArrayList<OrderItem> orderItemList = new ArrayList<>();
    private String orderAddress = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMyorderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().setFlags(1024, 1024);

        if (isUserAuthenticated()) {
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            orderRef = FirebaseDatabase.getInstance().getReference("orders").child(userId);

            binding.backBtn.setOnClickListener(view -> finish());

            fetchOrderData();
        } else {
            showLoginRequiredDialog();
        }
    }

    private boolean isUserAuthenticated() {
        return FirebaseAuth.getInstance().getCurrentUser() != null;
    }

    private void showLoginRequiredDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Login Required")
                .setMessage("You need to log in to view your orders.")
                .setPositiveButton("OK", (dialog, which) -> {

                    Intent intent = new Intent(MyorderActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private void fetchOrderData() {
        orderRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                orderItemList.clear();
                for (DataSnapshot orderSnapshot : snapshot.getChildren()) {

                    // Uncomment and use if needed to show address
                    // orderAddress = orderSnapshot.child("deliveryAddress").getValue(String.class);
                    // binding.addressTxt.setText(orderAddress);

                    for (DataSnapshot productSnapshot : orderSnapshot.child("products").getChildren()) {
                        OrderItem orderItem = productSnapshot.getValue(OrderItem.class);
                        if (orderItem != null) {
                            orderItemList.add(orderItem);
                        }
                    }

                    OrderAdapter adapter = new OrderAdapter(orderItemList);
                    binding.orderRecyclerView.setAdapter(adapter);
                    binding.orderRecyclerView.setLayoutManager(new LinearLayoutManager(MyorderActivity.this));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MyorderActivity.this, "Failed to load order data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
