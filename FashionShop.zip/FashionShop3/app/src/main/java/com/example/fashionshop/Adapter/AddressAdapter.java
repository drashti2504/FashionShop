package com.example.fashionshop.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.example.fashionshop.Domain.AddressDomain;
import com.example.fashionshop.Domain.ItemsDomain;
import com.example.fashionshop.databinding.ViewholderAddressBinding;

import java.util.ArrayList;

public class AddressAdapter extends RecyclerView.Adapter<AddressAdapter.ViewHolder> {
    ArrayList<AddressDomain> addressDomains;
    Context context;
    private int selectedPosition = -1;

    public AddressAdapter() {
    }

    public AddressAdapter(ArrayList<AddressDomain> addressDomains) {
        this.addressDomains = addressDomains;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setAddressList(ArrayList<AddressDomain> addressDomains) {
        this.addressDomains = addressDomains;
        notifyDataSetChanged();
    };

    @NonNull
    @Override
    public AddressAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        ViewholderAddressBinding binding = ViewholderAddressBinding.inflate(LayoutInflater.from(context),parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull AddressAdapter.ViewHolder holder, int position) {
        holder.binding.pname.setText(addressDomains.get(position).getName());
        holder.binding.addressAdd.setText(addressDomains.get(position).getHouseNo()+", "
                +addressDomains.get(position).getArea()+", "
                +addressDomains.get(position).getCity()+", "
                +addressDomains.get(position).getState()+", "
                +addressDomains.get(position).getOption());
        holder.binding.pincode.setText(String.valueOf(addressDomains.get(position).getPincode()));
        holder.binding.contactNoholder.setText(addressDomains.get(position).getContactNo());

        holder.binding.selectAddress.setChecked(position == selectedPosition);

        holder.binding.selectAddress.setOnClickListener(v -> {
            if (position != selectedPosition) {
                notifyItemChanged(selectedPosition);
                selectedPosition = position;
                notifyItemChanged(selectedPosition);
            }
        });

    }

    @Override
    public int getItemCount() {
        return addressDomains.size();
    }

    public AddressDomain getSelectedAddress() {
        if (selectedPosition != -1) {
            return addressDomains.get(selectedPosition);
        }
        return null; // No selection made
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ViewholderAddressBinding binding;
        public ViewHolder(ViewholderAddressBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
