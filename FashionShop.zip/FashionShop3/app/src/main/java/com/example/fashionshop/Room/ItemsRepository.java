package com.example.fashionshop.Room;

import android.app.Application;


import com.example.fashionshop.Domain.WishlistDomain;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class ItemsRepository {

    private ItemsDao itemsDao;

    public ItemsRepository(Application application) {
        ItemsDatabase database = ItemsDatabase.getInstance(application);
        itemsDao = database.favouriteDao();
    }

        public long insert(WishlistDomain item) {
        Future<Long> future = ItemsDatabase.databaseWriteExecutor.submit(() -> itemsDao.insert(item));
        try {
            return future.get(); // wait for the result
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
            return -1;
        }
    }


        public void delete(WishlistDomain item) {
            ItemsDatabase.databaseWriteExecutor.submit(() -> itemsDao.delete(item.getClothid()));
    }

        public boolean isFavourite(String favouriteitem) {
        Future<Boolean> future = ItemsDatabase.databaseWriteExecutor.submit(() -> itemsDao.getFavourite(favouriteitem) != null);
        try {
            return future.get(); // wait for the result
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
            return false;
        }
    }

        public List<WishlistDomain> getAllFavourites() {
        Future<List<WishlistDomain>> future = ItemsDatabase.databaseWriteExecutor.submit(() -> itemsDao.getAllFavourites());
        try {
            return future.get(); // wait for the result
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
            return Collections.emptyList();
        }
    }
}

