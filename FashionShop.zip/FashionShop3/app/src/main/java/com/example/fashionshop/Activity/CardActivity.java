package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fashionshop.Domain.CardDetails;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivityCardBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CardActivity extends BaseActivity {
    ActivityCardBinding binding;
    private EditText cardNumber, cardName, cardExpiry, cardCVV;
    private DatabaseReference databaseReference;
    private String cardNum, cardHolderName, expiry, cvv,totalprice;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        totalprice = getIntent().getStringExtra("price");

        cardName = findViewById(R.id.cardName);
        cardNumber = findViewById(R.id.cardNumber);
        cardExpiry = findViewById(R.id.expiryDate);
        cardCVV = findViewById(R.id.cvv);

        mAuth = FirebaseAuth.getInstance();


        binding.backBtn.setOnClickListener(view -> {
            Intent intent = new Intent(CardActivity.this, PaymentActivity.class);
            intent.putExtra("price",totalprice);
            startActivity(intent);
            finish();
        });


        cardNumber.addTextChangedListener(new TextWatcher() {
            private static final char space = ' ';

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String textWithoutSpaces = s.toString().replaceAll("\\s", "");

                StringBuilder formattedText = new StringBuilder();
                for (int i = 0; i < textWithoutSpaces.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formattedText.append(space);
                    }
                    formattedText.append(textWithoutSpaces.charAt(i));
                }

                cardNumber.removeTextChangedListener(this);
                cardNumber.setText(formattedText.toString());
                cardNumber.setSelection(formattedText.length());
                cardNumber.addTextChangedListener(this);
            }
        });

        cardCVV.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(4),
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                        if (source.length() > 0 && !Character.isDigit(source.charAt(0))) {
                            return "";
                        }
                        return null;
                    }
                }
        });


        cardExpiry.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting = false;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return; // Avoid re-triggering the watcher

                isFormatting = true;
                String text = s.toString();

                text = text.replaceAll("[^\\d]", "");

                StringBuilder formatted = new StringBuilder();
                if (text.length() > 2) {
                    formatted.append(text.substring(0, 2)).append('/');
                    if (text.length() > 4) {
                        formatted.append(text.substring(2, 4));
                    } else {
                        formatted.append(text.substring(2));
                    }
                } else {
                    formatted.append(text);
                }

                // Set the formatted text
                cardExpiry.setText(formatted.toString());
                cardExpiry.setSelection(formatted.length()); // Move cursor to the end

                isFormatting = false;
            }
        });



        setVariable();
    }

    private void setVariable() {
        binding.addCardBtn.setOnClickListener(view -> {
            cardHolderName = cardName.getText().toString().trim();
            cardNum = cardNumber.getText().toString().trim();
            expiry = cardExpiry.getText().toString().trim();
            cvv = cardCVV.getText().toString().trim();
            if(TextUtils.isEmpty(cardHolderName)){
                Toast.makeText(CardActivity.this,"Please enter card name",Toast.LENGTH_LONG).show();
                cardName.setError("card name is required");
                cardName.requestFocus();
            } else if (TextUtils.isEmpty(cardNum)) {
                Toast.makeText(CardActivity.this,"Please enter card number",Toast.LENGTH_LONG).show();
                cardNumber.setError("cardNumber is required");
                cardNumber.requestFocus();
            }
//            else if (!cardNum.matches("\\d{13,19}")) {
//                Toast.makeText(CardActivity.this, "Please enter a valid card number (13-19 digits)", Toast.LENGTH_LONG).show();
//                cardNumber.setError("Invalid card number");
//                cardNumber.requestFocus();
//            }
            else if (TextUtils.isEmpty(expiry)) {
                Toast.makeText(CardActivity.this,"Please enter expiry date",Toast.LENGTH_LONG).show();
                cardExpiry.setError("cardExpiry date is required");
                cardExpiry.requestFocus();
            }else if (!expiry.matches("(0[1-9]|1[0-2])/\\d{2}")) {
                Toast.makeText(CardActivity.this, "Please enter a valid expiry date (MM/YY)", Toast.LENGTH_LONG).show();
                cardExpiry.setError("Invalid expiry date");
            } else if (TextUtils.isEmpty(cvv)) {
                Toast.makeText(CardActivity.this,"Please enter your cvv",Toast.LENGTH_LONG).show();
                cardCVV.setError("card cvv is required");
                cardCVV.requestFocus();
            }else if (!cvv.matches("\\d{3,4}")) {
                Toast.makeText(CardActivity.this, "Please enter a valid CVV (3 or 4 digits)", Toast.LENGTH_LONG).show();
                cardCVV.setError("Invalid CVV");
                cardCVV.requestFocus();
            }else if(!binding.checkBoxSave.isChecked()) {
                Toast.makeText(CardActivity.this, "Are you sure to add the card detail!", Toast.LENGTH_LONG).show();
            } else {
                saveCardDetails();
                finish();
            }
        });
    }

    private void saveCardDetails() {

            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                String uid = currentUser.getUid();

                databaseReference = FirebaseDatabase.getInstance().getReference("CardDetails").child(uid);

                String id = databaseReference.push().getKey();

                CardDetails cardDetails = new CardDetails(cardNum, cardHolderName, expiry, cvv);
                databaseReference.child(id).setValue(cardDetails);

                Toast.makeText(this, "Card Details Saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User not authenticated. Please log in first.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(CardActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
    }
}
