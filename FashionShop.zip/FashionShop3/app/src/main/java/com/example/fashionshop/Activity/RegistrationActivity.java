package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fashionshop.Helper.ReadWriteuserDetails;
import com.example.fashionshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegistrationActivity extends AppCompatActivity {

    Button signup;
    EditText name,email,pwd,mobileno;
    private static final String TAG= "RegisterationActivity";
    CheckBox checkBox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration);

        signup = findViewById(R.id.signup);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        pwd = findViewById(R.id.pwd);
        mobileno = findViewById(R.id.mobileno);
        checkBox = findViewById(R.id.checkBox);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strname = name.getText().toString();
                String stremail = email.getText().toString();
                String strpwd = pwd.getText().toString();
                String strmobileno = mobileno.getText().toString();

                if(TextUtils.isEmpty(strname)){
                    Toast.makeText(RegistrationActivity.this,"Please enter your id",Toast.LENGTH_LONG).show();
                    name.setError("Name is required");
                    name.requestFocus();
                }  else if(TextUtils.isEmpty(stremail)){
                    Toast.makeText(RegistrationActivity.this,"Please enter your email",Toast.LENGTH_LONG).show();
                    email.setError("Email is required");
                    email.requestFocus();
                }else if(!Patterns.EMAIL_ADDRESS.matcher(stremail).matches()){
                    Toast.makeText(RegistrationActivity.this,"Please re-enter your email",Toast.LENGTH_LONG).show();
                    email.setError("valid email is required");
                    email.requestFocus();
                } else if (TextUtils.isEmpty(strmobileno)) {
                    Toast.makeText(RegistrationActivity.this, "Please enter mobileno", Toast.LENGTH_SHORT).show();
                    mobileno.setError("mobileno is required");
                    mobileno.requestFocus();
                } else if(TextUtils.isEmpty(strpwd)){
                    Toast.makeText(RegistrationActivity.this,"Please enter password",Toast.LENGTH_LONG).show();
                    pwd.setError("password is required");
                    pwd.requestFocus();
                } else if (strpwd.length() < 6) {
                    Toast.makeText(RegistrationActivity.this, "Password should be at least 6 digit", Toast.LENGTH_LONG).show();
                    pwd.setError("password to weak");
                    pwd.requestFocus();
                } else if (strmobileno.isEmpty()) {
                    Toast.makeText(RegistrationActivity.this, "Please enter your mobile number", Toast.LENGTH_LONG).show();
                    mobileno.setError("mobile number is required");
                    mobileno.requestFocus();
                }else if(!checkBox.isChecked()){
                    Toast.makeText(RegistrationActivity.this,"Please accept our terms and conditions",Toast.LENGTH_LONG).show();
                }else{
                    registerUser(strname,stremail,strmobileno,strpwd);
                }

            }
        });

    }

    private void registerUser(String strname, String stremail, String strmobileno, String strpwd){
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(stremail,strpwd).addOnCompleteListener(RegistrationActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    FirebaseUser firebaseUser = auth.getCurrentUser();

                    //update Display Name of User
                    UserProfileChangeRequest profileChangeRequest = new UserProfileChangeRequest.Builder().setDisplayName(strname).build();
                    firebaseUser.updateProfile(profileChangeRequest);

                    //realtime database
                    ReadWriteuserDetails writeuserDetails = new ReadWriteuserDetails(stremail,strmobileno);

                    //reference database "Register User"
                    DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Register User");

                    referenceProfile.child(firebaseUser.getUid()).setValue(writeuserDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if(task.isSuccessful()){
                                //send verifiy
                                firebaseUser.sendEmailVerification();
                                Toast.makeText(RegistrationActivity.this,"User Registered successfully.Please Verify your email.",Toast.LENGTH_LONG).show();

                                Intent intent = new Intent(RegistrationActivity.this,MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();

                            }else{
                                Toast.makeText(RegistrationActivity.this,"User Registration failed",Toast.LENGTH_LONG).show();
                            }

                        }
                    });

                } else {
                    try {
                        throw task.getException();
                    } catch (FirebaseAuthWeakPasswordException e){
                        pwd.setError("Your Password is to weak.Kindly use a mix of alphabeat,number and special characters.");
                        pwd.requestFocus();
                    } catch (FirebaseAuthInvalidCredentialsException e){
                        pwd.setError("Your email is invalid or alredy in use.Kindly re-enter .");
                        pwd.requestFocus();
                    } catch (FirebaseAuthUserCollisionException e){
                        pwd.setError("User is alredy registered with this email.Use another email.");
                        pwd.requestFocus();
                    } catch (Exception e){
                        Log.e(TAG,e.getMessage());
                        Toast.makeText(RegistrationActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    public void opensignin(View view){
        startActivity(new Intent(RegistrationActivity.this,LoginActivity.class));
    }

    public void appleweb(View view) {
        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(intent.CATEGORY_BROWSABLE);
        intent.setData(android.net.Uri.parse("https://www.apple.com/in/"));
        startActivity(intent);
    }

    public void googleweb(View view) {
        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(intent.CATEGORY_BROWSABLE);
        intent.setData(android.net.Uri.parse("https://www.google.com/"));
        startActivity(intent);
    }

    public void faceweb(View view) {
        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(intent.CATEGORY_BROWSABLE);
        intent.setData(android.net.Uri.parse("https://www.facebook.com/"));
        startActivity(intent);
    }
}