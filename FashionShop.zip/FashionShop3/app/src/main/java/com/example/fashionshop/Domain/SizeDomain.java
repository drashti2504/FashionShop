package com.example.fashionshop.Domain;

import java.io.Serializable;

public class SizeDomain implements Serializable {
    private String size;
    public SizeDomain(String size) {
        this.size = size;
    }
    public SizeDomain() {
    }
    public String getSize() {
        return size;
    }
    public void setSize(String  size) {
        this.size = size;
    }
}
