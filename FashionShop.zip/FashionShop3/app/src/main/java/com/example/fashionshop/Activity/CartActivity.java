package com.example.fashionshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.fashionshop.Adapter.CartAdapter;
import com.example.fashionshop.Domain.ItemsDomain;
import com.example.fashionshop.Helper.ChangeNumberItemsListener;
import com.example.fashionshop.Helper.ManagmentCart;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivityCartBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CartActivity extends BaseActivity {
    ActivityCartBinding binding;
    private double tax;
    String priceTotal;
    private ManagmentCart managmentCart;
    private DatabaseReference cartRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityCartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (isUserAuthenticated()) {
            String userId = getUserId();
            cartRef = FirebaseDatabase.getInstance().getReference("carts").child(userId);

            managmentCart = new ManagmentCart(this);

            syncCartWithFirebase();
            calculatorCart();
            setVariable();
            initCartList();
        } else {
            showLoginRequiredDialog();
        }
    }

    private boolean isUserAuthenticated() {
        return FirebaseAuth.getInstance().getCurrentUser() != null;
    }

    private void showLoginRequiredDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Login Required")
                .setMessage("You need to log in to view your cart.")
                .setPositiveButton("OK", (dialog, which) -> {

                    Intent intent = new Intent(CartActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private String getUserId() {
        return FirebaseAuth.getInstance().getCurrentUser().getUid();
    }

    private void initCartList() {
        if (managmentCart.getListCart().isEmpty()) {
            binding.emptyTxt.setVisibility(View.VISIBLE);
            binding.scrollViewCart.setVisibility(View.GONE);
        } else {
            binding.emptyTxt.setVisibility(View.GONE);
            binding.scrollViewCart.setVisibility(View.VISIBLE);
        }
        binding.cartView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        CartAdapter adapter = new CartAdapter(managmentCart.getListCart(), this, () -> {
            calculatorCart();
            updateFirebaseCart();
        });
        binding.cartView.setAdapter(adapter);
    }

    private void updateFirebaseCart() {
        cartRef.setValue(managmentCart.getListCart())
                .addOnSuccessListener(aVoid -> {
                    Log.d("Firebase", "Cart updated successfully");
                })
                .addOnFailureListener(e -> {
                    Log.e("Firebase", "Failed to update cart", e);
                });
    }

    private void syncCartWithFirebase() {
        cartRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<ItemsDomain> cartItems = new ArrayList<>();
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    ItemsDomain item = itemSnapshot.getValue(ItemsDomain.class);
                    if (item != null) {
                        cartItems.add(item);
                    }
                }
                managmentCart.setListCart(cartItems);
                initCartList();
                calculatorCart();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Firebase", "Failed to sync cart with Firebase", error.toException());
            }
        });
    }

    private void setVariable() {
        binding.backBtn.setOnClickListener(view -> finish());
        binding.checkOutBtn.setOnClickListener(view -> {
            if (isUserAuthenticated()) {
                Intent intent = new Intent(CartActivity.this, SelecteAddressActivity.class);
                intent.putExtra("price", priceTotal);
                startActivity(intent);
                finish();
            } else {
                showLoginRequiredDialog();
            }
        });
    }

    private void calculatorCart() {
        double percentTax = 0.02;
        double delivery = 10;
        tax = Math.round((managmentCart.getTotalFee() * percentTax * 100.0)) / 100;

        double total = Math.round((managmentCart.getTotalFee() + tax + delivery) * 100) / 100;
        double itemTotal = Math.round(managmentCart.getTotalFee() * 100) / 100;

        priceTotal = String.valueOf(total);

        binding.totalFeeTxt.setText("₹" + itemTotal);
        binding.taxTxt.setText("₹" + tax);
        binding.deliveryTxt.setText("₹" + delivery);
        binding.totalTxt.setText("₹" + total);
    }
}
