package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.fashionshop.Adapter.PopularAdapter;
import com.example.fashionshop.Domain.ItemsDomain;
import com.example.fashionshop.Domain.WishlistDomain;
import com.example.fashionshop.Room.ItemsRepository;
import com.example.fashionshop.databinding.ActivityWishlistBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class WishlistActivity extends BaseActivity {

    private ActivityWishlistBinding binding;
    private ItemsRepository itemRepository;
    private PopularAdapter popularAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWishlistBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        itemRepository = new ItemsRepository(this.getApplication());
        popularAdapter = new PopularAdapter();
        binding.wishlistProduct.setLayoutManager(new GridLayoutManager(this, 2));
        binding.wishlistProduct.setAdapter(popularAdapter);

        setVariable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFavorites();
    }

    private void loadFavorites() {
        List<WishlistDomain> favouriteItems = itemRepository.getAllFavourites();
        if (favouriteItems.isEmpty()) {
            binding.emptyfavTxt.setVisibility(View.VISIBLE);
            binding.wishlistProduct.setVisibility(View.GONE);
        } else {
            ArrayList<ItemsDomain> items = new ArrayList<>();
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Items");
            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            for (WishlistDomain favouriteItem : favouriteItems) {
                                if (dataSnapshot.getKey().equals(favouriteItem.getClothid())) {
                                    ItemsDomain item = dataSnapshot.getValue(ItemsDomain.class);
                                    if (item != null) {
                                        items.add(item);
                                    }
                                }
                            }
                        }
                        if (items.isEmpty()) {
                            binding.emptyfavTxt.setVisibility(View.VISIBLE);
                            binding.wishlistProduct.setVisibility(View.GONE);
                        } else {
                            binding.emptyfavTxt.setVisibility(View.GONE);
                            binding.wishlistProduct.setVisibility(View.VISIBLE);
                            popularAdapter.setProductList(items);
                        }
                    } else {
                        binding.emptyfavTxt.setVisibility(View.VISIBLE);
                        binding.wishlistProduct.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e("WishlistActivity", "Database error: " + error.getMessage());
                }
            });
        }
    }

    private void setVariable() {
        binding.backBtn.setOnClickListener(view -> finish());
    }
}
