package com.example.fashionshop.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fashionshop.Domain.ItemsDomain;
import com.example.fashionshop.Helper.ManagmentCart;
import com.example.fashionshop.R;
import com.example.fashionshop.databinding.ActivityAddressBinding;
import com.example.fashionshop.databinding.ActivityPaymentBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;

public class PaymentActivity extends BaseActivity {

    ActivityPaymentBinding binding;
    String totalprice;
    private ManagmentCart managmentCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityPaymentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

         totalprice = getIntent().getStringExtra("price");

        managmentCart=new ManagmentCart(this);

        getWindow().setFlags(1024,1024);


        binding.backBtn.setOnClickListener(v -> finish());

        binding.payBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    saveOrderToFirebase();
            }
        });

        binding.rightimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this,CardActivity.class);
                intent.putExtra("price",totalprice);
                startActivity(intent);
            }
        });

    }

    private void saveOrderToFirebase() {
        String userId = getUserId();
        DatabaseReference ordersRef = FirebaseDatabase.getInstance().getReference("orders").child(userId);

        String orderId = ordersRef.push().getKey();

        if (orderId == null) return; // Handle error

        HashMap<String, Object> orderData = new HashMap<>();
        orderData.put("totalPrice", totalprice);
       // orderData.put("deliveryAddress","Address User");
        orderData.put("status", "Pending");

        ArrayList<ItemsDomain> cartItems = managmentCart.getListCart();
        HashMap<String, Object> productsData = new HashMap<>();
        for (ItemsDomain item : cartItems) {
            HashMap<String, Object> productData = new HashMap<>();
            productData.put("title", item.getTitle());
            productData.put("price", item.getPrice());
            productData.put("quantity", item.getNumberInCart());
            productData.put("imageUrl", item.getPicUrl().get(0));
            productsData.put(item.getId(), productData);
        }
        orderData.put("products", productsData);

        ordersRef.child(orderId).setValue(orderData).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Intent intent = new Intent(PaymentActivity.this, SuccessfullActivity.class);
                intent.putExtra("price",totalprice);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to place order", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getUserId() {
        return FirebaseAuth.getInstance().getCurrentUser().getUid();
    }



}